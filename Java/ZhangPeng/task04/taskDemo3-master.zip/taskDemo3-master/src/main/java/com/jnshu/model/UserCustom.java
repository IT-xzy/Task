package com.jnshu.model;

public class UserCustom extends User{


}
