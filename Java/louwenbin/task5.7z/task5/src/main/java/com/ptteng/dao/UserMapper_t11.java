package com.ptteng.dao;

import com.ptteng.entity.UserT11;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface UserMapper_t11 {
    List<UserT11> getAll2();

}
