package com.ptteng.service;

import com.ptteng.entity.User;

import java.util.List;

public abstract interface UserService{
    List<User> getAll();

}

