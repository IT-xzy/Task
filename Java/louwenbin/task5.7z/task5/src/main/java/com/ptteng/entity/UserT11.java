package com.ptteng.entity;

public class UserT11 {
    private int id;
    private String t11_Career;
    private String t11_job;
    private int t11_study;
    private String t11_year1;
    private String t11_year2;
    private String t11_year3;
    private String t11_money1;
    private String t11_money2;
    private String t11_money3;
    private int t11_easy;
    private int t11_threshold;
    private int number;
    private String imges;

    @Override
    public String toString() {
        return "UserT11{" +
                "id=" + id +
                ", t11_Career='" + t11_Career + '\'' +
                ", t11_job='" + t11_job + '\'' +
                ", t11_study=" + t11_study +
                ", t11_year1='" + t11_year1 + '\'' +
                ", t11_year2='" + t11_year2 + '\'' +
                ", t11_year3='" + t11_year3 + '\'' +
                ", t11_money1='" + t11_money1 + '\'' +
                ", t11_money2='" + t11_money2 + '\'' +
                ", t11_money3='" + t11_money3 + '\'' +
                ", t11_easy=" + t11_easy +
                ", t11_threshold=" + t11_threshold +
                ", number=" + number +
                ", imges='" + imges + '\'' +
                '}';
    }

    public String getImges() {
        return imges;
    }

    public void setImges(String imges) {
        this.imges = imges;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getT11_Career() {
        return t11_Career;
    }

    public void setT11_Career(String t11_Career) {
        this.t11_Career = t11_Career;
    }

    public String getT11_job() {
        return t11_job;
    }

    public void setT11_job(String t11_job) {
        this.t11_job = t11_job;
    }

    public int getT11_study() {
        return t11_study;
    }

    public void setT11_study(int t11_study) {
        this.t11_study = t11_study;
    }

    public String getT11_year1() {
        return t11_year1;
    }

    public void setT11_year1(String t11_year1) {
        this.t11_year1 = t11_year1;
    }

    public String getT11_year2() {
        return t11_year2;
    }

    public void setT11_year2(String t11_year2) {
        this.t11_year2 = t11_year2;
    }

    public String getT11_year3() {
        return t11_year3;
    }

    public void setT11_year3(String t11_year3) {
        this.t11_year3 = t11_year3;
    }

    public String getT11_money1() {
        return t11_money1;
    }

    public void setT11_money1(String t11_money1) {
        this.t11_money1 = t11_money1;
    }

    public String getT11_money2() {
        return t11_money2;
    }

    public void setT11_money2(String t11_money2) {
        this.t11_money2 = t11_money2;
    }

    public String getT11_money3() {
        return t11_money3;
    }

    public void setT11_money3(String t11_money3) {
        this.t11_money3 = t11_money3;
    }

    public int getT11_easy() {
        return t11_easy;
    }

    public void setT11_easy(int t11_easy) {
        this.t11_easy = t11_easy;
    }

    public int getT11_threshold() {
        return t11_threshold;
    }

    public void setT11_threshold(int t11_threshold) {
        this.t11_threshold = t11_threshold;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
