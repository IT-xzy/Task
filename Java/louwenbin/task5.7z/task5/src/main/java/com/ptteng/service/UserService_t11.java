package com.ptteng.service;

import com.ptteng.entity.UserT11;

import java.util.List;

public interface UserService_t11 {
    List<UserT11> getAll2();
}
