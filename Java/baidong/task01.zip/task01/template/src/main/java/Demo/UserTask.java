package Demo;

public class UserTask {

     static UserDao dao = new UserDaoImpl();

    public static void main(String[] args) {
//        User s = new User();
//        s.setId(3);
//        s.setName("王明");
//        s.setType("UI");
//        s.setAdmissionTime(20170806);
//        s.setGraduatedSchool("哈佛园");
//        s.setDaliyLink("www.jnshu.com");
//        s.setVolunte("好好的");
//        s.setBrother("刘红");
//        s.setSource("知乎");
//        s.setCreateAt(20190101);
//        s.setUpdateAt(20190205);
        //System.out.println(dao.findById(1));


     //System.out.println(dao.add(s));
  //      System.out.println(dao.delete(1));
     System.out.println(dao.findAll());
     //   System.out.println(dao.update(s));

    }
}