package Demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao{

static ApplicationContext app = new ClassPathXmlApplicationContext("springbean.xml");
//创立一个类变量APP，调用ClassPathXmlApplicationContext类创建实例对象
   static JdbcTemplate jdbcTemplate = (JdbcTemplate)app.getBean("jdbcTemplate");
   //创立一个类变量jdbcTemplate，这里用的spring，未new对象，实现了解耦
   @Override
   //重构
   public boolean delete(int id) {
String sql = "delete from task00 where id = ?";//将sql语句的执行名命令放入sql变量
       int pp =jdbcTemplate.update(sql,id);//执行jdbcTemplate的update方法，将得到的值付给int。
       return pp>0;//判断pp是否大于0，返回一个人boolean类型
   }
   //修改语句
@Override
   public boolean update(User user) {
String sql = "update task00 set type=?,name=?,admission_time=?,graduated_school=?,daliy_link=?,volunte=?,brother=?,source=?,create_at=?,update_at=? where id=?";//将sql语句赋值给sql字符串

       int pp = jdbcTemplate.update(sql,user.getName(),user.getType(),user.getAdmissionTime(),
               user.getGraduatedSchool(), user.getDaliyLink(), user.getVolunte(),
               user.getBrother(), user.getSource(),
               user.getCreateAt(), user.getUpdateAt(),user.getId());
       return pp>0;
   }
//查找全部
@Override
   public List<User> findAll() {
String sql ="select * from task00";
       final List<User> ListAllStudent= new ArrayList<User>();
       jdbcTemplate.query(sql, new RowCallbackHandler() {
@Override
           public void processRow(ResultSet resultSet) throws SQLException {//重写这个方法。
User s = new User();
                //先resultSet的getint方法执行的
               s.setId(resultSet.getInt("id"));

               s.setName(resultSet.getString("name"));
                s.setType(resultSet.getString("Type"));
               s.setAdmissionTime(resultSet.getInt("Admission_time"));
               s.setGraduatedSchool(resultSet.getString("Graduated_school"));
               s.setDaliyLink(resultSet.getString("Daliy_link"));
               s.setVolunte(resultSet.getString("Volunte"));
               s.setBrother(resultSet.getString("Brother"));
               s.setSource(resultSet.getString("Source"));
               s.setCreateAt(resultSet.getInt("Create_at"));
               s.setUpdateAt(resultSet.getInt("Update_at"));
               ListAllStudent.add(s);
           }
});
       return ListAllStudent;
   }
//增加
@Override
   public int add(final User user) {
final String sql = "insert into task00 (id,name,type,admission_time,graduated_school,daliy_link,volunte,brother,,source,creat_at,update_at) values (?,?,?,?,?,?,?,?,?,?,?,)";
       KeyHolder keyHolder = new GeneratedKeyHolder();
       jdbcTemplate.update(new PreparedStatementCreator() {
@Override
           public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

               ps.setInt(1,user.getId());
               ps.setString(2,user.getName());
               ps.setString(3,user.getType());
               ps.setLong(4,user.getAdmissionTime());
               ps.setString(5,user.getGraduatedSchool());
               ps.setString(6,user.getDaliyLink());
               ps.setString(7,user.getVolunte());
               ps.setString(8,user.getBrother());
               ps.setString(9,user.getSource());
               ps.setLong(10,user.getCreateAt());
               ps.setLong(11,user.getUpdateAt());
               return ps;
           }
},keyHolder);
       return keyHolder.getKey().byteValue();
   }

@Override
//点点查询
   public User findById(int id) {
String sql = "select * from task00 where id = ?";
       final User user = new User();
       jdbcTemplate.query(sql, new RowMapper<Object>() {
           @Override
           public Object mapRow(ResultSet resultSet, int i) throws SQLException {
               user.setId(resultSet.getInt("id"));
               user.setName(resultSet.getString("name"));
               user.setType(resultSet.getString("type"));
               user.setAdmissionTime(resultSet.getLong("admission_time"));
               user.setGraduatedSchool(resultSet.getString("graduated_school"));
               user.setDaliyLink(resultSet.getString("daliy_link"));
               user.setVolunte(resultSet.getString("volunte"));
               user.setBrother(resultSet.getString("brother"));
               user.setSource(resultSet.getString("source"));
               user.setCreateAt(resultSet.getLong("create_at"));
               user.setUpdateAt(resultSet.getLong("update_at"));

               return user;
           }
       },id);
       return user;
       }
}
