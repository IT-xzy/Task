package Demo;

import java.sql.SQLException;
import java.util.List;
//添加数据返回ID，删除或更新数据返回True/False
public interface UserDao {
    List<User> findAll();
    //查找全部
    int add (User user);
    //增加
    boolean update (User user);
    //修改
    boolean delete(int id);
    //shanchu
    User findById(int id);
    //查找
}
