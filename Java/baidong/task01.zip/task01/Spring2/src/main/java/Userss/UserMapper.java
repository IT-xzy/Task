package Userss;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper {

    int add(User user);
   int delete (int id);
   int update(User user);
   List<User> findAll();
   User findById(int id);

}
