
import Userss.User;
import Userss.UserMapper;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class SpringTest {


	ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:ApplicationContext.xml");
	UserMapper userMapper = (UserMapper) applicationContext.getBean("userMapper");


	//	增
	@Test
	public void addUser() {

		User user = new User();
		user.setId(6);
		user.setName("小张");
		user.setCreateAt(20180509);
		System.out.println(userMapper.add(user));
	}

	//	查
	@Test
	public void findUserById() {

		System.out.println(userMapper.findById(2));

	}

	//	删
	@Test
	public void delete() {

		System.out.println(userMapper.delete(2));

	}

	//	改
	@Test
	public void update() {

		User user = new User();
		user.setId(2);
		user.setName("张毅");
		user.setCreateAt(20190506);
		int rs = userMapper.update(user);

		System.out.println(rs > 0);
	}

	@Test

	public void findAll() {

		System.out.println(userMapper.findAll());

	}
}



