package jnshu;


import org.apache.ibatis.annotations.*;

import java.util.List;

public interface UserMapper {
    @Insert("INSERT INTO task00 (name,type,admission_time,graduated_school,daliy_link,volunte,brother,source,create_at,update_at) VALUES (#{name},#{type},#{admissionTime},#{graduatedSchool},#{daliyLink},#{volunte},#{brother},#{source},#{createAt},#{updateAt})")
    @Options(keyProperty = "id", useGeneratedKeys = true)
    int add(User user);

    @Delete(" DELETE FROM task00 where id=#{id}")
    int delete(int id);

    @Update("UPDATE task00 SET name=#{name},type=#{type},admission_time=#{admissionTime},graduated_school=#{graduatedSchool},daliy_link=#{daliyLink},volunte=#{volunte},brother=#{brother},source=#{source},create_at=#{createAt},update_at=#{updateAt} WHERE id=#{id}")
    int update(User user);

    @Select("select * from task00")
    List<User> findAll();

    @Select("select * from task00 where id=#{id}")
    User findById(int id);

}

