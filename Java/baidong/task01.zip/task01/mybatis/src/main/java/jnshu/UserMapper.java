package jnshu;


import java.util.List;

public interface UserMapper {

   int add(User user);
   int delete (int id);
   int update(User user);
   List<User> findAll();
   User findById(int id);

}

