import jnshu.User;
import jnshu.UserMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;

import java.io.IOException;
import java.io.Reader;
import java.util.List;

public class test {


    //查
    @Test
    public void findAll() throws IOException {
        Reader reader = Resources.getResourceAsReader("cnfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sessionFactory.openSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);
        List<User> users = userMapper.findAll();
        System.out.println(users);
        session.close();

    }

    //   删
    public boolean deleteUser() throws IOException {

        Reader reader = Resources.getResourceAsReader("cnfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sessionFactory.openSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);
        int users = userMapper.delete(1);
        return users > 0;
    }

    @Test
    public void m() throws IOException {
        test test = new test();
        System.out.println(test.deleteUser());
    }

    //增
    @Test
    public void add() throws IOException {
        Reader reader = Resources.getResourceAsReader("cnfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sessionFactory.openSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);
        User user = new User();
        user.setName("张顺");
        user.setType("UI");
        int users = userMapper.add(user);

        System.out.println(users);
        session.commit();
        session.close();
    }

    //    改
    @Test
    public void update() throws IOException {
        Reader reader = Resources.getResourceAsReader("cnfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sessionFactory.openSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);
        User user = new User();
        user.setId(2);
        user.setName("张顺");
        user.setType("UI");
        int users = userMapper.update(user);

        System.out.println(users > 0);
        session.commit();
        session.close();
    }
//查单个
    @Test
    public void findById() throws IOException {
        Reader reader = Resources.getResourceAsReader("cnfig.xml");
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        SqlSession session = sessionFactory.openSession();
        UserMapper userMapper = session.getMapper(UserMapper.class);
        User users = userMapper.findById(1);//
        System.out.println(users);
        session.close();
    }
}
