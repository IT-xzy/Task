package Tes;
import java.sql.*;
public class Task {
    public static void main(String[] args) {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
        try {
//        注册驱动
            Class.forName("com.mysql.jdbc.Driver");
//        连接数据库
            String url = "jdbc:mysql://localhost:3306/task?serverTimezone=Asia/Shanghai";
            String user = "root";
            String password = "1111111111";
            conn = DriverManager.getConnection(url, user, password);
//        获取数据库的操作对象
            stmt = conn.createStatement();
//        执行sql语句
            String sql = "select * from task";
            rs = stmt.executeQuery(sql);
//            处理查询结果集
           while(rs.next()){
               long id = rs.getLong("id");
               String name = rs.getString("name");
               String career=rs.getString("career");
               String email = rs.getString("email");
                long createTime = rs.getLong("createtime");
               System.out.println(id + " " +name + " " + career +" " +
                       email +" " + createTime );
           }

        } catch (Exception e) {
            e.printStackTrace();
        }finally{
//            关闭资源
            if(rs!=null){
//                如果rs结果集不为空。则关闭认识，由于调用该方法会抛出异常，所以有try catch
                try {
                    rs.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
              if(stmt!=null){
                try {
                    stmt.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
                if(conn!=null){
                try {
                    conn.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

        }

    }
}
