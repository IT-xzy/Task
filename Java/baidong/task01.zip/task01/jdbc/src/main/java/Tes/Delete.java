package Tes;

import java.sql.*;



public class Delete {


    public static void main(String[] args) {


        Connection conn = null;
        Statement stmt = null;
        int rs = 0;
        try {
//        注册驱动
            Class.forName("com.mysql.jdbc.Driver");
//        连接数据库
            String url = "jdbc:mysql://localhost:3306/task?serverTimezone=Asia/Shanghai";
            String user = "root";
            String password = "1111111111";
            conn = DriverManager.getConnection(url, user, password);
//        获取数据库的操作对象
            stmt = conn.createStatement();
//        执行sql语句
            String sql = "delete from task where id = 1";
            rs = stmt.executeUpdate(sql);
//            处理查询结果集+
            System.out.println(rs);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            关闭资源
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }

    }
}

