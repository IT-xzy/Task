import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
public static void main(String[] args) throws Exception {
try {

//    加载驱动 注意先添加mysql-contector-java包
     Class.forName("com.mysql.jdbc.Driver");
//for循环
           for (int i = 0; i < 1000; i++) {

//               连接数据库
               Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/task03?useUnicode=true&characterEncoding=utf8&useSSL=false", "root", "1111111111");
               Statement statment = connection.createStatement();
               statment.execute("select * from task");
           }
       }catch(Exception e){
    System.out.println("有问题");
       }
     }
   }
