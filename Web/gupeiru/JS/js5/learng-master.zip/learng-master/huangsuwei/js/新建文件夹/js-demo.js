$(document).ready(function () {
    $('.class3').click(function () {
        $('#id2').css('background','blue');
    });
});
