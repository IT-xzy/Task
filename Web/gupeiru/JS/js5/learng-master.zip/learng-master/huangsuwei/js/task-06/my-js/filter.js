myApp.filter('typesFilter',function (types){
    return function (input) {
        if (input!=="" && input!== undefined){
            return types[input];
        }else {
            return"无"
        }
    }
});
myApp.filter("statusFilter",function (status) {
    return function (input) {
        if (input !== "" && input !== undefined ){
            return status[input]
        }else {
            return"无"
        }
    }
});
myApp.filter("putAwayFilter",function (putAway) {
    return function (input) {
        if (input!=="" && input!==undefined){
            return putAway[input];
        }else {
            return"无";
        }
    }
});